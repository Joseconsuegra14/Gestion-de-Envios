public class ShippingService {
    public double calculateCost(Envio envio) {
        return envio.calculateCost();
    }

}